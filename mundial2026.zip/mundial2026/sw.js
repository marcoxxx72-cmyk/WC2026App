// ═══════════════════════════════════════
//  SERVICE WORKER — Mundial 2026 PWA
// ═══════════════════════════════════════

const CACHE_NAME = "mundial2026-v2";
const ASSETS = [
  "/",
  "/index.html",
  "/app.js",
  "/manifest.json",
  "/icon-192.png",
  "/icon-512.png",
];

// Install — mise en cache des fichiers
self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(ASSETS).catch(() => {
        // Si certains assets manquent, on continue quand même
        return Promise.resolve();
      });
    })
  );
  self.skipWaiting();
});

// Activate — supprime les vieux caches
self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

// Fetch — stratégie Cache First puis Network
self.addEventListener("fetch", event => {
  // Ne pas intercepter les requêtes externes (CDN React, fonts...)
  if (!event.request.url.startsWith(self.location.origin)) return;

  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (!response || response.status !== 200) return response;
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => {
        // Hors ligne : retourne la page principale
        if (event.request.mode === "navigate") {
          return caches.match("/index.html");
        }
      });
    })
  );
});

// Push notifications (prêt pour plus tard)
self.addEventListener("push", event => {
  const data = event.data?.json() || {};
  self.registration.showNotification(data.title || "Mundial 2026 ⚽", {
    body: data.body || "Nouvelle mise à jour !",
    icon: "/icon-192.png",
    badge: "/icon-192.png",
  });
});
